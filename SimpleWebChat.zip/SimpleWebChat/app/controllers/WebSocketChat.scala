package controllers

import java.util.concurrent.atomic.AtomicInteger

import actors.ChatManager.LogoutMessage
import actors.{ChatActor, ChatManager}
import akka.actor.{ActorSystem, Props}
import akka.http.scaladsl.Http
import akka.http.scaladsl.model.ws.{Message, WebSocketRequest}
import akka.http.scaladsl.settings.ClientConnectionSettings
import akka.stream.Materializer
import akka.stream.scaladsl.{Flow, Sink, Source}
import akka.util.ByteString
import javax.inject.{Inject, Singleton}
import models.{TaskListInMemoryModel, UserData}
import play.api.libs.json.{JsError, JsSuccess, Json, Reads}
import play.api.libs.streams.ActorFlow
import play.api.mvc.{AbstractController, AnyContent, ControllerComponents, Request, Result, WebSocket}
import tasks.KeepAliveTask

import scala.concurrent.Future
import scala.concurrent.duration._

@Singleton
class WebSocketChat @Inject()(cc: ControllerComponents)(implicit system:ActorSystem, mat: Materializer) extends AbstractController(cc) with play.api.i18n.I18nSupport {

  import system.dispatcher
  val manager = system.actorOf(Props[ChatManager], "Manager")
  val keepAlive = new KeepAliveTask(system, manager)

  def index(username: String) = Action { implicit request =>
      Ok(views.html.chatPage(username)).addingToSession("username" -> username)
  }

  def logoutMessage() = Action { implicit request =>
    println(request.session.data.head._2)
    manager ! LogoutMessage(request.session.data.head._2)
    Redirect(routes.TaskList5.logout())
  }

  def socket() = WebSocket.accept[String,String] { implicit request =>

      ActorFlow.actorRef { out =>
        ChatActor.props(out, manager, request.session.data.head._2)
      }
    }

  }
