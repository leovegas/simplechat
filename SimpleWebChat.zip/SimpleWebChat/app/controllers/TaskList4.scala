package controllers

import javax.inject.{Inject, Singleton}
import models.{TaskListInMemoryModel, UserData}
import play.api.libs.json.{JsError, JsSuccess, Json, Reads}
import play.api.mvc.{AbstractController, ControllerComponents}

@Singleton
class TaskList4 @Inject()(cc: ControllerComponents) extends AbstractController(cc) with play.api.i18n.I18nSupport {

  def load = Action { implicit request =>
    Ok(views.html.version5Main())
  }




}
