package controllers

import actors.ChatManager
import actors.ChatManager.LogoutMessage
import akka.actor.{ActorSystem, Props}
import akka.stream.Materializer
import javax.inject.{Inject, Singleton}
import models.{TaskItem, TaskListDatabaseModel, UserData}
import play.api.db.slick.{DatabaseConfigProvider, HasDatabaseConfigProvider}
import play.api.libs.json.{JsError, JsSuccess, Json, Reads, Writes}
import play.api.mvc.{AbstractController, AnyContent, ControllerComponents, Request, Result}
import play.mvc.Action
import slick.jdbc.JdbcProfile
import slick.jdbc.PostgresProfile.api._

import scala.concurrent.{ExecutionContext, Future}

@Singleton
class TaskList5 @Inject()(protected val dbConfigProvider: DatabaseConfigProvider, cc: ControllerComponents)(implicit ec: ExecutionContext)
  extends AbstractController(cc) with play.api.i18n.I18nSupport with HasDatabaseConfigProvider[JdbcProfile] {

  private val model = new TaskListDatabaseModel(db)

  def load = Action { implicit request =>
    Ok(views.html.version6Main())
  }

  implicit val UserDataReads: Reads[UserData] = Json.reads[UserData]
  implicit val itemDataWrites: Writes[TaskItem] = Json.writes[TaskItem]


  def withJsonBody[A](f: A => Future[Result])(implicit request: Request[AnyContent], reads: Reads[A]): Future[Result] = {
    request.body.asJson.map { body =>
      Json.fromJson[A](body) match {
        case JsSuccess(a, path) => f(a)
        case e@JsError(_) => Future.successful(Redirect(routes.TaskList5.load()))
      }
    }.getOrElse(Future.successful(Redirect(routes.TaskList5.load())))
  }

  def withSessionUsername(f: String => Future[Result])(implicit request: Request[AnyContent]): Future[Result] = {
    request.session.get("username").map(f).getOrElse(Future.successful(Ok(Json.toJson(Seq.empty[String]))))
  }

  def withSessionUserid(f: Int => Future[Result])(implicit request: Request[AnyContent]): Future[Result] = {
    request.session.get("userid").map(userid => f(userid.toInt)).getOrElse(Future.successful(Ok(Json.toJson(Seq.empty[String]))))
  }

  def validate = Action.async { implicit request =>
    withJsonBody[UserData] { ud =>
      model.validateUser(ud.username, ud.password, true).map {
        case Some(userid) =>
          Ok(Json.toJson(true))
            .withSession("username" -> ud.username, "userid" -> userid.toString, "csrfToken" -> play.filters.csrf.CSRF.getToken.map(_.value).getOrElse(""))
        case None =>
          Ok(Json.toJson(false))
      }
    }
  }

  def createUser = Action.async { implicit request =>
    withJsonBody[UserData] { ud =>
      model.createUser(ud.username, ud.password, false).map {
        case Some(userid) =>
          Ok(Json.toJson(true))
            .withSession("username" -> ud.username, "userid" -> userid.toString, "csrfToken" -> play.filters.csrf.CSRF.getToken.map(_.value).getOrElse(""))
        case None =>
          Ok(Json.toJson(false))
      }
    }
  }

  def taskList = Action.async { implicit request =>
    withSessionUsername { username =>
      model.getTasks(username).map(tasks => Ok(Json.toJson(tasks)))
    }
  }


  def addTask = Action.async { implicit request =>
    withSessionUserid { userid =>
      withJsonBody[String] { task =>
        model.addTask(userid, task).map(count => Ok(Json.toJson(count > 0)))
      }
    }
  }

  def delete = Action.async { implicit request =>
    withSessionUsername { username =>
      withJsonBody[Int] { itemId =>
        model.removeTask(itemId).map(removed => Ok(Json.toJson(removed)))
      }
    }
  }
//
//  def logout = Action { implicit request =>
//    Ok(Json.toJson(true)).withSession(request.session - "username")
//  }

  def logout = Action.async { implicit request =>
    withSessionUsername {username =>
      model.logoutUpdateStatus(username, false).map {
        case Some(_) =>
          Redirect(routes.TaskList3.load()).withSession(request.session - "username")
        case None =>
          Ok("")
      }
    }
  }



}
