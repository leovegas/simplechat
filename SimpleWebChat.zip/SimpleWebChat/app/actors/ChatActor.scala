package actors

import actors.ChatActor.SendMessage
import actors.ChatManager.Chatter
import akka.actor.{Actor, ActorRef, ActorSystem, Props}
import tasks.KeepAliveTask

class ChatActor(out: ActorRef, manager: ActorRef, username: String) extends Actor{

  manager ! ChatManager.NewChatter(Chatter(self, username))

  override def receive: Receive = {
    case s: String => manager ! ChatManager.Message(s, username)
    case SendMessage(msg) => out ! msg
  }
}

object ChatActor {
  def props(out: ActorRef, manager: ActorRef, username: String) = Props(new ChatActor(out, manager, username))
  case class SendMessage(msg: String)
}