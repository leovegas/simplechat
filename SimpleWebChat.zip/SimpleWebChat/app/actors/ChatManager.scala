package actors

import actors.ChatManager.{Chatter, LogoutMessage, Message, NewChatter}
import akka.actor.{Actor, ActorRef}

class ChatManager extends Actor{
  private var chatters = List.empty[Chatter]

  override def receive: Receive = {
    case "tick009" => for (c <- chatters) c.actor ! "tick009"
    case NewChatter(chatter) => chatters ::= chatter
    case Message(msg, username) => for (c <- chatters) c.actor ! ChatActor.SendMessage(username+": "+msg)
    case LogoutMessage(username) => for (c <- chatters) c.actor ! ChatActor.SendMessage(username + " logged out ")
  }
}

object ChatManager {
  case class LogoutMessage(username: String)
  case class NewChatter(chatter: Chatter)
  case class Message(msg: String, username: String)
  case class Chatter(actor: ActorRef, username: String)
}
