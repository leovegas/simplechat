package models

import scala.collection.mutable
import slick.jdbc.PostgresProfile.api._

import scala.concurrent.{ExecutionContext, Future}
import models.Tables._
import org.mindrot.jbcrypt.BCrypt


class TaskListDatabaseModel(db: Database)(implicit ec: ExecutionContext) {

  def validateUser(username: String, password: String, status: Boolean): Future[Option[Int]] = {
    db.run(
      (for {
        user <- Users if user.username === username
      } yield {
        user
      }).map(_.online).update(status))
    val matches = db.run(Users.filter(userRow => userRow.username === username).result)
    matches.map(userRows => userRows.headOption.flatMap {
      userRow => if (BCrypt.checkpw(password, userRow.password)) Some(userRow.id) else None
    })
  }

  def createUser(username: String, password: String, status: Boolean): Future[Option[Int]] = {
    val matches = db.run(Users.filter(userRow => userRow.username === username).result)
    matches.flatMap { userRows =>
      if (userRows.isEmpty) {
        db.run(Users += UsersRow(-1, username, BCrypt.hashpw(password, BCrypt.gensalt()), status))
          .flatMap { addCount =>
            if (addCount > 0) db.run(Users.filter(userRow => userRow.username === username).result)
              .map(_.headOption.map(_.id))
            else Future.successful(None)
          }
      } else Future.successful(None)
    }
  }

  def getTasks(username: String): Future[Seq[TaskItem]] = {
    db.run(
      (for {
        user <- Users if user.username === username
        item <- Items if item.userId === user.id
      } yield {
        // TaskItem(item.itemId, item.text)
        item
      }).result
    ).map(_.map(itemRow => TaskItem(itemRow.itemId, itemRow.text)))
  }

  def addTask(userid: Int, task: String): Future[Int] = {
    db.run(Items += ItemsRow(-1, userid, task))
  }

  def removeTask(itemId: Int): Future[Boolean] = {
    db.run(Items.filter(_.itemId === itemId).delete).map(count => count > 0)
  }

  def logoutUpdateStatus(username: String, status: Boolean): Future[Option[Int]] = {
    db.run(
      (for {
        user <- Users if user.username === username
      } yield {
        user
      }).map(_.online).update(status)
    ).flatMap { addCount =>
      if (addCount > 0) db.run(Users.filter(userRow => userRow.username === username).result)
        .map(_.headOption.map(_.id))
      else Future.successful(None)
    }
  }


}
