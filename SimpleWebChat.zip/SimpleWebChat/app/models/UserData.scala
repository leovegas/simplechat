package models

case class UserData(username:String, password:String, status: Boolean) {

}
