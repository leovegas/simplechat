package models

case class TaskItem(id:Int, text:String) {

}
