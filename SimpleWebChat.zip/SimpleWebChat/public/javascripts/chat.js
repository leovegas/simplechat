/**
 * Code for chat app
 **/

const inputField = document.getElementById("chat-input");
const outputArea = document.getElementById("chat-area");
const username = document.getElementById("username").value;

outputArea.scrollTop = outputArea.scrollHeight;
outputArea.readOnly = "false";

const socketRoute = document.getElementById("ws-route").value;
const socket = new WebSocket(socketRoute.replace("http", "ws"));

const button = document.getElementById("sendButton");
button.onclick = (event) => {
    socket.send(inputField.value);
    inputField.value = '';
    outputArea.scrollTop = outputArea.scrollHeight
};

inputField.onkeydown = (event) => {
    if (event.key === 'Enter') {
        socket.send(inputField.value);
        inputField.value = '';
        outputArea.scrollTop = outputArea.scrollHeight;
    }
};

socket.onopen = () => {
    socket.send(" logged in ");
    outputArea.scrollTop = outputArea.scrollHeight;
    window.setTimeout(removeLine, 5000);
}


socket.onmessage = (event) => {
    console.log("Got "+event.data)
    if (!event.data.endsWith('tick009')){
        outputArea.value += '\n' + event.data;
        outputArea.scrollTop = outputArea.scrollHeight;
        window.setTimeout(removeLine, 5000);
    }

    };

function removeLine()
{
    var removeval = outputArea.value;
    removeval = removeval.trim();
    var n = removeval.split("\n");
    n.forEach(el => {
        if (el.endsWith(' logged in')||el.startsWith(' logged out')) {
            delete n[n.indexOf(el)]
        }
    });
    outputArea.value = n.join('\n');
    n.forEach(e => {

    })
}

// function sendMessge()
// {
//     socket.send("tick009");
// }
//
// function runAgain()
// {
//     window.setInterval(sendMessge, 10000);
// }
//
// runAgain();







