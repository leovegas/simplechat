
"use strict"

const validateRoute = document.getElementById("validateRoute").value;
const createRoute =   document.getElementById("createRoute").value;
const deleteRoute =   document.getElementById("deleteRoute").value;
const addRoute =      document.getElementById("addRoute").value;
const csrfToken =     document.getElementById("csrfToken").value;
const tasksRoute =    document.getElementById("tasksRoute").value;
const passwordField = document.getElementById("loginPass");


function onEnter() {
    passwordField.onkeydown = (e)=> {
        if (e.key === 'Enter') {
            login();
        }
    };
}

onEnter();

function  login() {
    const username = document.getElementById("loginName").value;
    const password = document.getElementById("loginPass").value;
    const status = true;

    fetch(validateRoute, {
        method: 'POST',
        headers: {'Content-Type':'application/json', 'Csrf-Token': csrfToken},
        body: JSON.stringify({username,password,status})
    }).then (res => res.json())
      .then (data => {
          if (data) {
              window.location="/chat/"+username;
              document.getElementById("loginName").value = "";
        }else {
              document.getElementById("loginName").value = "Login Failed";
              document.getElementById("loginPass").value = "";
          }
    })
}



function loadTasks() {
    const ul = document.getElementById("task-list");
    fetch(tasksRoute).then(res => res.json()).then(tasks => {
        for (let i = 0; i<tasks.length; ++i) {
           const li = document.createElement("li");
           const text = document.createTextNode(tasks[i]);
           li.appendChild(text);
           li.onclick = e => {
               ul.innerHTML="";
               fetch(deleteRoute, {
                   method: 'POST',
                   headers: {'Content-Type':'application/json', 'Csrf-Token': csrfToken},
                   body: JSON.stringify(i)
               }).then (res => res.json())
                   .then (data => {
                       if (data) {
                           loadTasks()
                           document.getElementById("task-message").innerHTML = "";
                       }else {
                           document.getElementById("task-message").innerHTML = "Failed to delete";
                       }
                   })
           }
           ul.appendChild(li);
        }
    })
}

function addTask() {
    const task = document.getElementById("newTask").value;
    const ul = document.getElementById("task-list");
    fetch(addRoute, {
        method: 'POST',
        headers: {'Content-Type':'application/json', 'Csrf-Token': csrfToken},
        body: JSON.stringify(task)
    }).then (res => res.json())
        .then (data => {
            if (data) {
                const li = document.createElement("li");
                const text = document.createTextNode(task);
                li.appendChild(text);
                ul.appendChild(li);
                document.getElementById("newTask").value="";
                document.getElementById("task-message").innerHTML = "";

            }else {
                document.getElementById("task-message").innerHTML = "Failed to add";
            }
        })
}

function visibleCreateUser() {
    document.getElementById("login-section").hidden = true;
    document.getElementById("register-section").hidden = false;
}

function visibleLogin() {
    document.getElementById("login-section").hidden = false;
    document.getElementById("register-section").hidden = true;
}

function invisibleCreateUser() {
    document.getElementById("register-section").hidden = true;
}

function invisibleLogin() {
    document.getElementById("login-section").hidden = true;
}

function  logout() {
    const username = document.getElementById("createName").value;
    const password = document.getElementById("createPass").value;
    const status = false;

    fetch(createRoute, {
        method: 'POST',
        headers: {'Content-Type':'application/json', 'Csrf-Token': csrfToken},
        body: JSON.stringify({username,password,status})
    }).then (res => res.json())
        .then (data => {
            if (data) {
                document.getElementById("login-section").hidden = false;
                document.getElementById("task-section").hidden = false;
                document.getElementById("register-section").hidden = true;
                document.getElementById("create-message").innerHTML = "";
                loadTasks();
            }else {
                document.getElementById("create-message").innerHTML = "Creating Failed";
            }
        })
}

function  createUser() {
    const username = document.getElementById("createName").value;
    const password = document.getElementById("createPass").value;
    const status = false;

    fetch(createRoute, {
        method: 'POST',
        headers: {'Content-Type':'application/json', 'Csrf-Token': csrfToken},
        body: JSON.stringify({username,password,status})
    }).then (res => res.json())
        .then (data => {
            if (data) {
                document.getElementById("login-section").hidden = false;
                document.getElementById("task-section").hidden = false;
                document.getElementById("register-section").hidden = true;
                document.getElementById("create-message").innerHTML = "";
                loadTasks();
            }else {
                document.getElementById("create-message").innerHTML = "Creating Failed";
            }
        })
}